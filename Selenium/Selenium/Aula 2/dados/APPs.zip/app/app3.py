import openpyxl

book = openpyxl.load_workbook("DADOS.xlsx")

print(book.sheetnames)


book.create_sheet("DADOS02")
print(book.sheetnames)

DADOS02_page = book["DADOS02"]
DADOS02_page.append(["Salário", "Horas", "Presença"])
DADOS02_page.append(["2000", "10", "Sim"])
DADOS02_page.append(["4000", "15", "Parcial"])
DADOS02_page.append(["3000", "50", "Imparcial"])

Dados_page = book["DADOS"]

for rows in Dados_page.iter_rows(min_row=1,max_row=7):
    print(rows[0].value,rows[1].value,rows[2].value,rows[3].value)

book.save("DADOS.xlsx")